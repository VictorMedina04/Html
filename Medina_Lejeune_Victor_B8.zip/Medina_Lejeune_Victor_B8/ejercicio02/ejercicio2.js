//Mensaje de texto pero en variable
let mensaje = "Mensaje de texto";
alert(mensaje);