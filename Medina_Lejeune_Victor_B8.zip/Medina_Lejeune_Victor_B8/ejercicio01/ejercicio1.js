//Mensaje
alert("Mensaje de texto");