let numero = prompt("Número para calcular el factorial:");
let factorial = 1;
for (let i = 1; i <= n; i++) {
      factorial *= i;
    }

alert("El factorial de " +numero+ " es: " + factorial);
